
public class Student {

	String firstName;
	String lastName;
	int id;

	public Student (int id, String firstName, String lastName) {
		this.id=id;
		this.firstName=firstName;
		this.lastName=lastName;
			
		
	}
	
}
