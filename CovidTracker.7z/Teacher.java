
public class Teacher {
	
	String firstName;
	String lastName;
	int id;

	public Teacher (int id, String firstName, String lastName) {
		this.id=id;
		this.firstName=firstName;
		this.lastName=lastName;
			
		
	}
	
}
